# GRB 241201A Research

This repository contains all research data, analysis scripts, and results.